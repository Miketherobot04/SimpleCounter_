# Simple Counter App

This is a basic Android application built with Kotlin that allows users to tap a button to increment a counter.
It also features an upgrade system where users can upgrade the tap to add more points per click.

## Features
- Tap to increase counter.
- Upgrade to add 2 per tap after reaching 100 taps.
- Custom background and button icon.

## How to Run
1. Open the project in Android Studio.
2. Connect an emulator or physical device.
3. Click 'Run' to build and deploy the app.

## Demo
![Demo GIF](demo.gif)